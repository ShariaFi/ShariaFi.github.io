import { Lesson } from './types';

export const hobbiesData = [
  { id: 1, verbAr: "يَقْرَأ", verbIn: "Membaca", masdarAr: "القِرَاءَة", masdarIn: "Reading" },
  { id: 2, verbAr: "يَطْبُخ", verbIn: "Memasak", masdarAr: "الطَّبْخ", masdarIn: "Cooking" },
  { id: 3, verbAr: "يَلْعَب", verbIn: "Bermain", masdarAr: "اللَّعِب", masdarIn: "Playing" },
  { id: 4, verbAr: "يَسْبَح", verbIn: "Berenang", masdarAr: "السِّبَاحَة", masdarIn: "Swimming" },
  { id: 5, verbAr: "يَرْسُم", verbIn: "Menggambar", masdarAr: "الرَّسْم", masdarIn: "Drawing" },
  { id: 6, verbAr: "يُسَافِر", verbIn: "Bepergian", masdarAr: "السَّفَر", masdarIn: "Travel" },
  { id: 7, verbAr: "يُصَوِّر", verbIn: "Memotret", masdarAr: "التَّصْوِير", masdarIn: "Photography" }
];

export const sampleLesson: Lesson = {
  id: 'lesson-1',
  title: 'أساسيات بناء الكلمة: الفعل والمصدر',
  description: 'مقدمة في الجذور (Verbs) والمصادر (Nouns) في اللغة العربية وكيفية التمييز بينها.',
  blocks: [
    {
      id: 'block-1',
      type: 'heading',
      content: '1. الجذور والمصادر',
    },
    {
      id: 'block-2',
      type: 'text',
      content: 'في اللغة العربية، العديد من الكلمات تُشتق من جذر ثلاثي الأحرف. الفعل يُمثل الحدث (أزرق)، والمصدر يُمثل الاسم المشتق من ذلك الحدث (برتقالي).',
    },
    {
      id: 'block-3',
      type: 'semantic-sentence',
      words: [
        { text: 'الطالب', type: 'normal', translation: 'The student' },
        { text: 'يَكْتُبُ', type: 'root', translation: 'writes (verb/root)' },
        { text: 'الدرس', type: 'normal', translation: 'the lesson' },
        { text: 'بِـ', type: 'normal', translation: 'with' },
        { text: 'كِتَابَةٍ', type: 'masdar', translation: 'writing (noun/masdar)' },
        { text: 'واضحة.', type: 'positive', translation: 'clear (positive)' },
      ],
    },
    {
      id: 'block-4',
      type: 'text',
      content: 'لاحظ كيف أن "يكتب" تعبر عن الفعل، بينما "كتابة" هي المصدر لنفس الجذر (ك-ت-ب).',
    },
    {
      id: 'block-5',
      type: 'heading',
      content: '2. أمثلة إضافية للاستيعاب',
    },
    {
      id: 'block-6',
      type: 'semantic-sentence',
      words: [
        { text: 'العالِم', type: 'normal', translation: 'The scientist' },
        { text: 'يَبْحَثُ', type: 'root', translation: 'researches (verb)' },
        { text: 'في المعمل، و', type: 'normal', translation: 'in the lab, and' },
        { text: 'البَحْثُ', type: 'masdar', translation: 'the research (noun)' },
        { text: 'مستمر', type: 'positive', translation: 'ongoing' },
        { text: 'بشكل', type: 'normal', translation: 'in a manner' },
        { text: 'خاطئ.', type: 'negative', translation: 'wrong' },
      ],
    },
    {
      id: 'block-7',
      type: 'heading',
      content: 'اختبر معلوماتك',
    },
    {
      id: 'block-8',
      type: 'quiz',
      content: 'ما هو المصدر الموافق للفعل "قَرَأَ"؟',
      options: ['يقرأ', 'اقرأ', 'قِراءَة', 'قارئ'],
      correctAnswer: 2,
    }
  ],
};
