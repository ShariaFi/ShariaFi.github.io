export interface WordWord {
  text: string;
  type?: 'root' | 'masdar' | 'positive' | 'negative' | 'normal';
  translation?: string;
}

export interface LessonContent {
  id: string;
  type: 'text' | 'semantic-sentence' | 'quiz' | 'heading';
  content?: string;
  words?: WordWord[];
  options?: string[];
  correctAnswer?: number;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  blocks: LessonContent[];
}
