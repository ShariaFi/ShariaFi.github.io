import React, { useState } from 'react';
import { CheckCircle2, XCircle } from 'lucide-react';

interface QuizProps {
  question: string;
  options: string[];
  correctAnswer: number;
}

export const QuizBlock = ({ question, options, correctAnswer }: QuizProps) => {
  const [selected, setSelected] = useState<number | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSelect = (index: number) => {
    if (!isSubmitted) setSelected(index);
  };

  const handleSubmit = () => {
    if (selected !== null) setIsSubmitted(true);
  };

  return (
    <div className="my-6 p-6 md:p-8 bg-white border border-slate-200 rounded-2xl shadow-sm">
      <h3 className="text-xl font-bold text-slate-800 mb-6">{question}</h3>
      <div className="space-y-3">
        {options.map((opt, idx) => {
          let styleClass = "border-slate-200 hover:border-blue-300 hover:bg-blue-50 text-slate-700";
          
          if (isSubmitted) {
            if (idx === correctAnswer) {
              styleClass = "border-green-500 bg-green-50 text-green-800";
            } else if (idx === selected) {
              styleClass = "border-red-500 bg-red-50 text-red-800";
            } else {
              styleClass = "border-slate-200 opacity-50";
            }
          } else if (selected === idx) {
            styleClass = "border-blue-500 bg-blue-50 text-blue-800 ring-1 ring-blue-500";
          }

          return (
            <button
              key={idx}
              onClick={() => handleSelect(idx)}
              disabled={isSubmitted}
              className={`w-full text-right p-4 rounded-xl border-2 transition-all flex justify-between items-center ${styleClass}`}
            >
              <span className="text-lg font-semibold">{opt}</span>
              {isSubmitted && idx === correctAnswer && <CheckCircle2 className="w-5 h-5 text-green-600" />}
              {isSubmitted && selected === idx && idx !== correctAnswer && <XCircle className="w-5 h-5 text-red-600" />}
            </button>
          );
        })}
      </div>
      
      {!isSubmitted && (
        <button
          onClick={handleSubmit}
          disabled={selected === null}
          className="mt-6 w-full py-4 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          تحقق من الإجابة
        </button>
      )}
      
      {isSubmitted && (
        <button
          onClick={() => {
            setSelected(null);
            setIsSubmitted(false);
          }}
          className="mt-6 w-full py-4 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-bold text-lg transition-colors"
        >
          حاول مرة أخرى
        </button>
      )}
    </div>
  );
};
