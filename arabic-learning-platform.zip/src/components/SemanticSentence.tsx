import React from 'react';
import { WordWord } from '../types';

export const SemanticSentence = ({ words }: { words: WordWord[] }) => {
  return (
    <div className="flex flex-wrap gap-2 text-xl md:text-2xl font-semibold leading-loose p-6 bg-white border border-slate-200 rounded-xl shadow-sm my-4">
      {words.map((word, idx) => {
        let colorClass = 'text-slate-800';
        let bgClass = '';
        
        switch (word.type) {
          case 'root':
            colorClass = 'text-root';
            bgClass = 'bg-blue-50';
            break;
          case 'masdar':
            colorClass = 'text-masdar';
            bgClass = 'bg-orange-50';
            break;
          case 'positive':
            colorClass = 'text-positive';
            bgClass = 'bg-green-50';
            break;
          case 'negative':
            colorClass = 'text-negative';
            bgClass = 'bg-red-50';
            break;
        }

        return (
          <div key={idx} className="group relative flex flex-col items-center cursor-help">
            <span className={`px-2 py-1 rounded-md transition-colors ${colorClass} ${bgClass} hover:bg-opacity-80`}>
              {word.text}
            </span>
            {word.translation && (
              <div className="absolute -top-10 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap bg-slate-800 text-white text-xs font-sans px-3 py-1.5 rounded-lg pointer-events-none z-10 shadow-lg">
                {word.translation}
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-800" />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
