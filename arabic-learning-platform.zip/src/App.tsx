import React, { useState, useEffect } from 'react';
import { hobbiesData } from './data';
import { ArrowLeft, CheckCircle2, RefreshCw, Volume2 } from 'lucide-react';

export default function App() {
  const emotions = [
    { id: 'suka', ar: 'أُحِبُّ', in: 'Saya suka', colorClass: 'suka' },
    { id: 'lebih-suka', ar: 'أُفَضِّلُ', in: 'Saya lebih suka', colorClass: 'lebih-suka' },
    { id: 'tidak-suka', ar: 'لا أُحِبُّ', in: 'Saya tidak suka', colorClass: 'tidak-suka' },
    { id: 'benci', ar: 'أَكْرَهُ', in: 'Saya benci', colorClass: 'benci' },
  ];
  const [selectedEmotion, setSelectedEmotion] = useState(emotions[0]);
  const [droppedHobbyId, setDroppedHobbyId] = useState<number | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);

  useEffect(() => {
    if (droppedHobbyId !== null) {
      setCountdown(3);
    } else {
      setCountdown(null);
    }
  }, [droppedHobbyId]);

  useEffect(() => {
    if (countdown !== null && countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  return (
    <div className="max-w-3xl mx-auto min-h-screen bg-gray-50 flex flex-col text-slate-800 font-sans" dir="rtl">
      {/* Main Content Area */}
      <main className="flex-1 px-4 sm:px-6 py-8">
        
        {/* Title */}
        <div className="mb-12 pt-4">
          <h2 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-8 text-center leading-relaxed">
            الأسبوع السابع: الهواية <bdi dir="ltr" className="whitespace-nowrap inline-block">(Al-Hiwayah)</bdi>
          </h2>
        </div>

        {/* SECTION 1: The Emotional Control Panel */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-slate-900 mb-2">
            كيف تشعر؟ 
          </h3>
          <bdi dir="ltr" className="block text-sm font-semibold text-gray-500 mb-6">(Bagaimana perasaanmu?)</bdi>

          <div className="bg-blue-50 border-r-4 border-blue-500 p-3 mb-4 rounded-l-md text-sm text-slate-700">
            في اللغة العربية، نبدأ الجملة بتحديد شعورنا أولاً. <bdi dir="ltr">(Di bahasa Arab, kita memulai kalimat dengan menentukan perasaan kita terlebih dahulu).</bdi>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {emotions.map((emotion) => {
              const isActive = selectedEmotion.id === emotion.id;
              const colorMappings: Record<string, string> = {
                'suka': 'hover:bg-suka hover:border-suka',
                'lebih-suka': 'hover:bg-lebih-suka hover:border-lebih-suka',
                'tidak-suka': 'hover:bg-tidak-suka hover:border-tidak-suka',
                'benci': 'hover:bg-benci hover:border-benci'
              };
              const activeColorMappings: Record<string, string> = {
                'suka': 'bg-suka border-suka text-white shadow-md',
                'lebih-suka': 'bg-lebih-suka border-lebih-suka text-white shadow-md',
                'tidak-suka': 'bg-tidak-suka border-tidak-suka text-white shadow-md',
                'benci': 'bg-benci border-benci text-white shadow-md'
              };

              return (
                <button
                  key={emotion.id}
                  onClick={() => setSelectedEmotion(emotion)}
                  className={`
                    group relative flex flex-col items-center justify-center p-6 rounded-2xl border-2 transition-all duration-300
                    ${isActive 
                      ? activeColorMappings[emotion.colorClass] 
                      : `bg-white border-slate-200 text-slate-700 ${colorMappings[emotion.colorClass]} hover:text-white`
                    }
                  `}
                >
                  <span className="text-3xl font-bold mb-2">{emotion.ar}</span>
                  <bdi dir="ltr" className={`text-sm font-semibold tracking-wide uppercase ${isActive ? 'opacity-90' : 'text-slate-500 group-hover:text-white/90'}`}>
                    {emotion.in}
                  </bdi>
                </button>
              );
            })}
          </div>
        </div>

        {/* SECTION 2: Mesin Masdar Grid */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-slate-900 mb-2">
            مصنع الهوايات
          </h3>
          <bdi dir="ltr" className="block text-sm font-semibold text-gray-500 mb-6">(Mesin Masdar)</bdi>

          <div className="bg-purple-50 border-r-4 border-purple-500 p-3 mb-4 rounded-l-md text-sm text-slate-700">
            للتعبير عن الهواية، لا نستخدم 'الفعل'، بل نحوله إلى 'اسم/مصدر'. انظر كيف يتغير الشكل: <bdi dir="ltr">(Untuk mengekspresikan hobi, kita tidak menggunakan 'Kata Kerja', melainkan mengubahnya menjadi 'Kata Benda/Masdar'. Lihat perubahannya:)</bdi>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4" id="masdar-grid">
            {hobbiesData.map((hobby) => (
              <div key={hobby.id} className="bg-white hover:shadow-md transition-shadow border border-slate-200 rounded-xl p-4 flex flex-col items-center justify-center text-center gap-3">
                <div className="flex items-center justify-between w-full">
                  <div className="flex flex-col items-center flex-1">
                    <span className="text-2xl font-bold text-slate-800 mb-1">{hobby.verbAr}</span>
                    <bdi dir="ltr" className="text-xs font-semibold text-gray-500 uppercase tracking-wide">{hobby.verbIn}</bdi>
                  </div>
                  <ArrowLeft className="w-5 h-5 text-slate-300 flex-shrink-0 mx-2" />
                  <div 
                    className="flex flex-col items-center flex-1 cursor-grab active:cursor-grabbing hover:bg-purple-50 rounded-lg p-2 transition-all drag-element"
                    draggable={true}
                    onDragStart={(e) => {
                      e.dataTransfer.setData('text/plain', hobby.id.toString());
                      e.currentTarget.classList.add('opacity-40', 'scale-95');
                    }}
                    onDragEnd={(e) => {
                      e.currentTarget.classList.remove('opacity-40', 'scale-95');
                    }}
                  >
                    <span className="text-2xl font-bold text-masdar mb-1">{hobby.masdarAr}</span>
                    <bdi dir="ltr" className="text-xs font-semibold text-gray-500 uppercase tracking-wide">{hobby.masdarIn}</bdi>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* SECTION 3: Sentence Builder Drop Zone */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-slate-900 mb-2">
            ركّب الجملة
          </h3>
          <bdi dir="ltr" className="block text-sm font-semibold text-gray-500 mb-6">(Susun Kalimat)</bdi>

          <div className="bg-green-50 border-r-4 border-green-500 p-3 mb-4 rounded-l-md text-sm text-slate-700">
            الآن، اجمع 'الشعور' مع 'الاسم' لإنشاء جملتك الخاصة. <bdi dir="ltr">(Sekarang, gabungkan 'Perasaan' dengan 'Kata Benda' untuk membuat kalimatmu sendiri.)</bdi>
          </div>

          <div 
            className="border-2 border-dashed border-slate-300 bg-slate-50 rounded-2xl p-8 flex flex-col items-center justify-center min-h-[160px] transition-colors"
            onDragOver={(e) => {
              e.preventDefault();
              e.currentTarget.classList.add('bg-slate-100', 'border-blue-400');
            }}
            onDragLeave={(e) => {
              e.currentTarget.classList.remove('bg-slate-100', 'border-blue-400');
            }}
            onDrop={(e) => {
              e.preventDefault();
              e.currentTarget.classList.remove('bg-slate-100', 'border-blue-400');
              const idStr = e.dataTransfer.getData('text/plain');
              if (idStr) {
                setDroppedHobbyId(parseInt(idStr, 10));
              }
            }}
          >
            {droppedHobbyId === null && (
              <div className="flex flex-col items-center pointer-events-none mb-4">
                <span className="text-xl font-bold text-slate-400 text-center">
                  اسحب الهواية إلى هنا
                </span>
                <bdi dir="ltr" className="block text-sm font-semibold text-gray-400 mt-2">(Tarik Hobi ke sini)</bdi>
              </div>
            )}
            
            {droppedHobbyId && (
              <div className="flex flex-col items-center gap-6 mb-4">
                <div className="flex items-center flex-wrap justify-center gap-3 text-4xl md:text-5xl font-bold bg-white p-6 rounded-2xl shadow-sm border border-slate-200 text-center leading-relaxed">
                  <span style={{ color: `var(--color-${selectedEmotion.colorClass})` }}>
                    {selectedEmotion.ar}
                  </span>
                  <span className="text-masdar">
                    {hobbiesData.find(h => h.id === droppedHobbyId)?.masdarAr}
                  </span>
                  <span className="text-slate-700">
                    فِي وَقْتِ الفَرَاغِ
                  </span>
                </div>
                <div className="text-xl font-bold text-green-600 bg-green-50 px-6 py-2 rounded-full flex items-center gap-2">
                  <CheckCircle2 className="w-6 h-6" />
                  <bdi dir="ltr">Bagus sekali!</bdi>
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-center mt-4">
            <div className="bg-white px-6 py-3 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
               <span className="text-2xl font-bold text-slate-700">فِي وَقْتِ الفَرَاغِ</span>
               <bdi dir="ltr" className="text-sm font-bold text-gray-500 uppercase tracking-wide">(Di waktu luang)</bdi>
            </div>
          </div>

          {droppedHobbyId && countdown !== null && countdown > 0 && (
            <div className="mt-8 flex flex-col items-center justify-center p-6 bg-blue-50 border-2 border-blue-200 rounded-2xl animate-pulse">
              <Volume2 className="w-12 h-12 text-blue-600 mb-3" />
              <p className="text-xl md:text-2xl font-bold text-blue-800 mb-2 text-center">
                انطق الجملة بصوت عالٍ!
              </p>
              <bdi dir="ltr" className="block text-lg font-bold text-blue-600 mb-4 text-center">
                (Ucapkan dengan keras!)
              </bdi>
              <div className="text-5xl font-extrabold text-blue-700">
                {countdown}
              </div>
            </div>
          )}
          {droppedHobbyId && countdown === 0 && (
            <div className="mt-8 flex justify-center animate-in fade-in zoom-in duration-300">
              <button 
                onClick={() => setDroppedHobbyId(null)}
                className="flex items-center gap-2 px-6 py-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold rounded-xl shadow-sm transition-colors"
              >
                <RefreshCw className="w-5 h-5" />
                <bdi dir="ltr">Buat Kalimat Lain</bdi>
              </button>
            </div>
          )}
        </div>

        {/* SECTION 4: Dialog Klub Chat UI */}
        <div className="mb-12 mt-16 pt-8 border-t border-slate-200">
          <div className="flex flex-col items-center justify-center mb-10">
            <h3 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <span className="bg-green-100 text-green-600 p-3 rounded-full shadow-sm">
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/></svg>
              </span>
              حوار النادي
            </h3>
            <bdi dir="ltr" className="block text-sm text-gray-500 mt-2 font-semibold uppercase tracking-wide">(Dialog Klub)</bdi>
          </div>

          <div className="max-w-2xl mx-auto flex flex-col gap-6">
            
            {/* Right Bubble (Khaled) */}
            <div className="flex gap-3 self-start max-w-[90%] md:max-w-[80%] items-start">
              <div className="w-10 h-10 rounded-full bg-gray-200 flex-shrink-0 flex items-center justify-center font-bold text-gray-600 text-sm mt-1">خ</div>
              <div className="bg-gray-100 p-5 rounded-2xl rounded-tr-none shadow-sm relative border border-gray-200 text-right">
                <p className="text-xl md:text-2xl font-bold text-slate-800 leading-relaxed mb-2">السَّلامُ عَلَيْكُمْ يا طارق. مَاذَا تَفْعَلُ فِي وَقْتِ الفَرَاغِ؟</p>
                <bdi dir="ltr" className="block text-sm font-semibold text-gray-500 tracking-wide mt-1">(Assalamu'alaikum Tariq. Apa yang kamu lakukan di waktu luang?)</bdi>
              </div>
            </div>

            {/* Left Bubble (Tariq) */}
            <div className="flex gap-3 flex-row-reverse self-end max-w-[90%] md:max-w-[80%] items-start">
              <div className="w-10 h-10 rounded-full bg-green-200 flex-shrink-0 flex items-center justify-center font-bold text-green-800 text-sm mt-1">ط</div>
              <div className="bg-green-100 p-5 rounded-2xl rounded-tl-none shadow-sm relative border border-green-200 text-right">
                <p className="text-xl md:text-2xl font-bold text-green-900 leading-relaxed mb-2">وَعَلَيْكُمُ السَّلام. أُحِبُّ مُمَارَسَةَ الرِّيَاضَةِ. وَمَا هِوَايَتُكَ أَنْتَ؟</p>
                <bdi dir="ltr" className="block text-sm font-medium text-green-700 tracking-wide mt-1">(Wa'alaikumsalam. Saya suka berolahraga. Dan apa hobimu?)</bdi>
              </div>
            </div>

            {/* Right Bubble (Khaled) */}
            <div className="flex gap-3 self-start max-w-[90%] md:max-w-[80%] items-start">
              <div className="w-10 h-10 rounded-full bg-gray-200 flex-shrink-0 flex items-center justify-center font-bold text-gray-600 text-sm mt-1">خ</div>
              <div className="bg-gray-100 p-5 rounded-2xl rounded-tr-none shadow-sm relative border border-gray-200 text-right">
                <p className="text-xl md:text-2xl font-bold text-slate-800 leading-relaxed mb-2">هِوَايَتِي القِرَاءَةُ. هَلْ تُحِبُّ القِرَاءَةَ؟</p>
                <bdi dir="ltr" className="block text-sm font-semibold text-gray-500 tracking-wide mt-1">(Hobiku membaca. Apakah kamu suka membaca?)</bdi>
              </div>
            </div>

            {/* Left Bubble (Tariq) */}
            <div className="flex gap-3 flex-row-reverse self-end max-w-[90%] md:max-w-[80%] items-start">
              <div className="w-10 h-10 rounded-full bg-green-200 flex-shrink-0 flex items-center justify-center font-bold text-green-800 text-sm mt-1">ط</div>
              <div className="bg-green-100 p-5 rounded-2xl rounded-tl-none shadow-sm relative border border-green-200 text-right">
                <p className="text-xl md:text-2xl font-bold text-green-900 leading-relaxed mb-2">لا أُحِبُّ القِرَاءَةَ كَثِيراً، أُفَضِّلُ السَّفَرَ.</p>
                <bdi dir="ltr" className="block text-sm font-medium text-green-700 tracking-wide mt-1">(Tidak, saya tidak terlalu suka membaca, saya lebih suka bepergian.)</bdi>
              </div>
            </div>
            
          </div>
        </div>

        {/* Exit Node CTA */}
        <div className="max-w-2xl mx-auto bg-amber-50 border-2 border-amber-200 p-8 rounded-2xl mt-16 shadow-sm text-center">
          <h4 className="text-2xl font-extrabold text-amber-800 mb-2">تَدْرِيبُ النَّادِي</h4>
          <p className="text-xl font-bold text-amber-900 mb-3">استعد لتطبيق هذا الحوار مع زميلك!</p>
          <bdi dir="ltr" className="block text-sm font-bold text-amber-700 uppercase tracking-wide">(Tugas Klub: Bersiaplah mempraktikkan dialog ini dengan temanmu!)</bdi>
        </div>

      </main>
    </div>
  );
}

